#!/bin/sh
cd /etc/openvpn/pia
openvpn --config pia_nl.conf --daemon
sleep 5 # Leave time for VPN to connect
transmission-daemon --foreground
